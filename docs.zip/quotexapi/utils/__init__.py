"""Module for Quotex API playwright."""
